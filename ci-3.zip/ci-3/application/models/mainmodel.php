<?php
class Mainmodel extends CI_Model{
	
	function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	function getParliaments(){
		$qstring = "SELECT * FROM CDP.parliaments";
		$query = $this->db->query($qstring);
		$result = $query->result_array();
		return $result;
	}

	function getParliament($id){
		$qstring = "SELECT * FROM CDP.parliaments WHERE id = '$id'";
		$query = $this->db->query($qstring);
		$result = $query->row_array();
		return $result;
	}

	function getAssemblies(){
		$qstring = "SELECT * FROM CDP.assemblies";
		$query = $this->db->query($qstring);
		$result = $query->result_array();
		return $result;
	}

	function getAssembly($id){
		$qstring = "SELECT * FROM CDP.assemblies WHERE id = '$id'";
		$query = $this->db->query($qstring);
		$result = $query->result_array();
		return $result;
	}

	function getParliamentAssemblies($id){
		$qstring = "SELECT * FROM CDP.assemblies WHERE parliament_id IN($id)";
		$query = $this->db->query($qstring);
		$result = $query->result_array();
		return $result;
	}

	function getDistricts(){
		$qstring = "SELECT * FROM CDP.districts";
		$query = $this->db->query($qstring);
		$result = $query->result_array();
		return $result;
	}

	function getDistrict($id){
		$qstring = "SELECT * FROM CDP.districts WHERE id = '$id'";
		$query = $this->db->query($qstring);
		$result = $query->result_array();
		return $result;
	}

	function getAssemblyDistricts($id){
		$qstring = "SELECT * FROM CDP.districts WHERE assembly_id IN($id)";
		$query = $this->db->query($qstring);
		$result = $query->result_array();
		return $result;
	}

	function getBlocks(){
		$qstring = "SELECT * FROM CDP.blocks";
		$query = $this->db->query($qstring);
		$result = $query->result_array();
		return $result;
	}

	function getBlock($id){
		$qstring = "SELECT * FROM CDP.blocks WHERE id = '$id'";
		$query = $this->db->query($qstring);
		$result = $query->result_array();
		return $result;
	}

	function getDistrictBlocks($id){
		$qstring = "SELECT * FROM CDP.blocks WHERE district_id IN($id)";
		$query = $this->db->query($qstring);
		$result = $query->result_array();
		return $result;
	}

	function getPanchayats(){
		$qstring = "SELECT * FROM CDP.panchayats";
		$query = $this->db->query($qstring);
		$result = $query->result_array();
		return $result;
	}

	function getPanchayat($id){
		$qstring = "SELECT * FROM CDP.panchayats WHERE id = '$id'";
		$query = $this->db->query($qstring);
		$result = $query->result_array();
		return $result;
	}

	function getBlockPanchayats($id){
		$qstring = "SELECT * FROM CDP.panchayats WHERE block_id IN($id)";
		$query = $this->db->query($qstring);
		$result = $query->result_array();
		return $result;
	}

	function getVillages(){
		$qstring = "SELECT * FROM CDP.villages";
		$query = $this->db->query($qstring);
		$result = $query->result_array();
		return $result;
	}

	function getVillage($id){
		$qstring = "SELECT * FROM CDP.villages WHERE id = '$id'";
		$query = $this->db->query($qstring);
		$result = $query->result_array();
		return $result;
	}

	function getPanchayatVillages($id){
		$qstring = "SELECT * FROM CDP.villages WHERE panchayat_id IN($id)";
		$query = $this->db->query($qstring);
		$result = $query->result_array();
		return $result;
	}
	


	function getBooths(){
		$qstring = "SELECT * FROM CDP.booths";
		$query = $this->db->query($qstring);
		$result = $query->result_array();
		return $result;
	}

	function getBooth($id){
		$qstring = "SELECT * FROM CDP.booths WHERE id = '$id'";
		$query = $this->db->query($qstring);
		$result = $query->result_array();
		return $result;
	}

	function getVillageBooths($id){
		$qstring = "SELECT * FROM CDP.booths WHERE village_id IN($id)";
		$query = $this->db->query($qstring);
		$result = $query->result_array();
		return $result;
	}

	function getBlockBooths($id){
		$qstring = "SELECT * FROM CDP.booths WHERE block_id IN($id)";
		$query = $this->db->query($qstring);
		$result = $query->result_array();
		return $result;
	}

	function getVoters(){
		$qstring = "SELECT * FROM CDP.voters";
		$query = $this->db->query($qstring);
		$result = $query->result_array();
		return $result;
	}

	function getVoter($id){
		$qstring = "SELECT * FROM CDP.voters WHERE id = '$id'";
		$query = $this->db->query($qstring);
		$result = $query->result_array();
		return $result;
	}

	function getBoothVoters($boothId,$draw,$start,$rowperpage,$columnIndex,$columnName,$columnSortOrder,$searchValue){
		$searchQuery = "";
		if($searchValue != ''){
        	$searchQuery = " AND (name LIKE '%".$searchValue."%' or email LIKE '%".$searchValue."%' or address LIKE'%".$searchValue."%' ) ";
     	}

		$qstring = "SELECT * FROM CDP.voters WHERE booth_id IN($boothId)";
		
		$query = $this->db->query($qstring);
		$data['totalRecords'] = $query->num_rows();

		if($searchQuery != ''){
        	$qstring .= $searchQuery;
    	}
    	$query = $this->db->query($qstring);
		$data['totalRecordwithFilter'] = $query->num_rows();

     	$qstring .= " ORDER BY ".$columnName." ".$columnSortOrder." LIMIT $start, $rowperpage";
		//echo $qstring;

		$query = $this->db->query($qstring);
		$data['result'] = $query->result_array();
		return $data;
	}

	function saveBoothPresident($data) {
		$qstring = "INSERT INTO CDP.booth_presidents (id, name, email, mobile, gender, address, pincode, booth_id, village_id, panchayat_id, block_id, assembly_id, parliament_id) VALUES (NULL, '".$data['name']."', '".$data['email']."', '".$data['mobile']."', ".$data['gender'].", '".$data['address']."', '".$data['pincode']."', ".$data['boothId'].", ".$data['villageId'].", ".$data['panchayatId'].", ".$data['blockId'].", ".$data['assemblyId'].", ".$data['parliamentId'].");";
		$query = $this->db->query($qstring);
		return ($this->db->affected_rows() > 0);
		// $result = $query->result_array();

		// return $result;
	}
}
