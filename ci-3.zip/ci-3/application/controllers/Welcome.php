<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Mainmodel');

	}

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */
	public function index()
	{
        $data = array();
		$data['parliamentId'] =  (isset($_POST['parliament'])) ? $_POST['parliament'] : 0;
		$data['assemblyId'] = (isset($_POST['assembly'])) ? $_POST['assembly'] : 0;
		$data['districtId'] = (isset($_POST['district'])) ? $_POST['district'] : 0;
		$data['blockId'] = (isset($_POST['block'])) ? $_POST['block'] : 0;
		$data['blockId'] = (isset($_POST['block'])) ? $_POST['block'] : 0;
		$data['panchayatId'] = (isset($_POST['panchayat'])) ? $_POST['panchayat'] : 0;
		$data['villageId'] = (isset($_POST['village'])) ? $_POST['village'] : 0;
		// $data['parliaments'] = $this->Mainmodel->getParliaments();
		$data['assemblies'] = $this->Mainmodel->getAssemblies();
		$data['blocks']  = array();
		$data['booths']  = array();
		$data['voters']  = array();
		if ($data['assemblyId']){
			$data['districts'] = $this->Mainmodel->getAssemblyDistricts($data['assemblyId']);
			if($data['districtId']){
				$data['blocks'] = $this->Mainmodel->getDistrictBlocks($data['districtId']);
			}
			if($data['blockId']){
				$data['panchayats'] = $this->Mainmodel->getBlockPanchayats($data['blockId']);
				// $data['booths'] = $this->Mainmodel->getBlockBooths($data['blockId']);
			}
			if($data['panchayatId']){
				$data['villages'] = $this->Mainmodel->getPanchayatVillages($data['panchayatId']);
			}
			if($data['villageId']){
				$data['booths'] = $this->Mainmodel->getVillageBooths($data['villageId']);
			}
		}
		$this->load->view('home_page', $data);
	}

	public function listVoters()
	{   
		$boothId = (isset($_POST['boothId'])) ? $_POST['boothId'] : 1;
		$draw = (isset($_POST['draw'])) ? $_POST['draw'] : 0;
	    $start = (isset($_POST['start'])) ? $_POST['start'] : 0;
	    $rowperpage = (isset($_POST['length'])) ? $_POST['length'] : 0;// Rows display per page
	    $columnIndex = (isset($_POST['order'][0]['column'])) ? $_POST['order'][0]['column'] : 0;// Column index
	    $columnName = (isset($_POST['columns'][$columnIndex]['data'])) ? $_POST['columns'][$columnIndex]['data'] : ""; // Column name
	    $columnSortOrder = (isset($_POST['order'][0]['dir'])) ? $_POST['order'][0]['dir'] : 0;// asc or desc
	    $searchValue = (isset($_POST['search']['value'])) ? $_POST['search']['value'] : 0;// Search value
	    $voters = array();
	    $votersData = $this->Mainmodel->getBoothVoters($boothId,$draw,$start,$rowperpage,$columnIndex,$columnName,$columnSortOrder,$searchValue);
		if(isset($votersData) && isset($votersData['result']) && count($votersData['result'])){
			foreach($votersData['result'] as $voter ){
		        $voters[] = array(
		           "name"=>$voter['name'],
		           "mobile"=>$voter['mobile'],
		           "email"=>$voter['email'],
		           "gender"=>$voter['gender'],
		           "pincode"=>$voter['pincode'],
		           "address"=>$voter['address']
		        ); 
		    }
		}
	    $totalRecords = (isset($votersData['totalRecords'])) ? $votersData['totalRecords'] : 17;
	    $totalRecordwithFilter = (isset($votersData['totalRecordwithFilter'])) ? $votersData['totalRecordwithFilter'] : 17;

	     ## Response
	    $response['draw'] = intval($draw);
	    $response['iTotalRecords'] = $votersData['totalRecords'];
	    $response['iTotalDisplayRecords'] = $votersData['totalRecordwithFilter'];
	    $response['data'] = $voters;
	    echo json_encode($response);
	}

	public function home()
	{
		$data = array();
		$data['parliamentId'] =  (isset($_POST['parliament'])) ? $_POST['parliament'] : 0;
		$data['assemblyId'] = (isset($_POST['assembly'])) ? $_POST['assembly'] : 0;
		$data['districtId'] = (isset($_POST['district'])) ? $_POST['district'] : 0;
		$data['blockId'] = (isset($_POST['block'])) ? $_POST['block'] : 0;
		$data['panchayatId'] = (isset($_POST['panchayat'])) ? $_POST['panchayat'] : 0;
		$data['villageId'] = (isset($_POST['village'])) ? $_POST['village'] : 0;
		$data['boothId'] = (isset($_POST['booth'])) ? $_POST['booth'] : 0;
		$data['parliaments'] = $this->Mainmodel->getParliaments();
		$data['assemblies'] = $this->Mainmodel->getAssemblies();
		$data['blocks']  = array();
		$data['booths']  = array();
		$data['voters']  = array();
		if ($data['assemblyId']){
			$data['districts'] = $this->Mainmodel->getAssemblyDistricts($data['assemblyId']);
			if($data['districtId']){
				$data['blocks'] = $this->Mainmodel->getDistrictBlocks($data['districtId']);
			}
			if($data['blockId']){
				$data['panchayats'] = $this->Mainmodel->getBlockPanchayats($data['blockId']);
				// $data['booths'] = $this->Mainmodel->getBlockBooths($data['blockId']);
			}
			if($data['panchayatId']){
				$data['villages'] = $this->Mainmodel->getPanchayatVillages($data['panchayatId']);
			}
			if($data['villageId']){
				$data['booths'] = $this->Mainmodel->getVillageBooths($data['villageId']);
			}
		}
		$this->load->view('agent_registration', $data);
	}

	public function saveBoothPresident()
	{
		$data = (isset($_POST['data'])) ?  $_POST['data'] : []; 
		// echo $data;
		//print_r($data);
		// echo json_encode($data);
		// echo $data['parliament'];
		// return;
		$data['parliamentId'] =  (isset($data['parliament'])) ? $data['parliament'] : 0;
		$data['assemblyId'] = (isset($data['assembly'])) ? $data['assembly'] : 0;
		$data['blockId'] = (isset($data['block'])) ? $data['block'] : 0;
		$data['panchayatId'] = (isset($data['panchayat'])) ? $data['panchayat'] : 0;
		$data['villageId'] = (isset($data['village'])) ? $data['village'] : 0;
		$data['boothId'] = (isset($data['booth'])) ? $data['booth'] : 0;
		$data['name'] =     (isset($data['name'])) ? $data['name'] : "";
		$data['mobile'] = (isset($data['mobile'])) ? $data['mobile'] : "";
		$data['email'] = (isset($data['email'])) ? $data['email'] : "";
		$data['gender'] = (isset($data['gender'])) ? $data['gender'] : 0;
		$data['address'] = (isset($data['address'])) ? $data['address'] : "";
		$data['pincode'] = (isset($data['pincode'])) ? $data['pincode'] : "";
		$data['result'] = $this->Mainmodel->saveBoothPresident($data);
		if ($data['result']) {
			echo "201";
		} else {
			echo "503";
		}
	}
}
