<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<head>
  <title>CDP</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
  <!-- Datatable CSS -->
     <link href='//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css' rel='stylesheet' type='text/css'>
     <!-- jQuery Library -->
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
     <!-- Datatable JS -->
     <script src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">CDP</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Link</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Dropdown
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="http://localhost/ci-3/index.php/home">Booth President</a>
          <a class="dropdown-item" href="#">User Registration</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Something else here</a>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link disabled" href="#">Disabled</a>
      </li>
    </ul>
    <!-- <ul class="navbar-nav mr-auto">
      <img src="<?php echo base_url("/assets/static/images/party-logo.png");?>" alt="party-logo">
    </ul> -->
    <form class="form-inline my-2 my-lg-0">
      <!-- <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search"> -->
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Login</button>
    </form>
  </div>
</nav>

<div class="text-center">
  <h3>Booth President Registration Page</h3>
  <span id="error" style="color:red; display:none;"></span>
  <span id="success" style="color:green; display:none;">Successfully registered!</span>
</div>
<form action="<?=$_SERVER['PHP_SELF']?>" method="post" name="form" id="form">
  <input type="hidden" id="parliament" name="parliament" value="0" />
  <input type="hidden" id="assembly" name="assembly" value="0" />
  <input type="hidden" id="district" name="district" value="0" />
  <input type="hidden" id="block" name="block" value="0" />
  <input type="hidden" id="panchayat" name="panchayat" value="0" />
  <input type="hidden" id="village" name="village" value="0" />
  <input type="hidden" id="booth" name="booth" value="0" />
</form>
<div class="container col-md-8">
  <div class="row col-sm-12 col-md-12">
    <div class="col-sm-6 col-md-6">
      <div class="dropdown form-group">
        <!-- <label for="cars">Select Parliament</label> -->
        <!-- <select name="parliaments" class="parliaments form-control">
          <option value="0">Select Parliament</option>
          <?php //foreach ($parliaments as $parliament) {?>
            <option <?php //echo (isset($parliamentId) && $parliamentId == $parliament['id']) ? ' selected ' : '';?>value="<?php //echo $parliament['id'];?>"><?php echo $parliament['name'];?></option>
          <?php //}?>
        </select> -->
        <label for="Assemblies">Select Assembly</label>
        <select name="Assemblies" class="assemblies form-control">
          <option value="0">Select Assembly</option>
          <?php if(isset($assemblies) && count($assemblies) > 0){
            foreach ($assemblies as $assembly) {?>
            <option <?php echo (isset($assemblyId) && $assemblyId == $assembly['id']) ? ' selected ' : '';?>value="<?php echo $assembly['id'];?>"><?php echo $assembly['name'];?></option>
          <?php }}?>
        </select>
      </div>
    </div>
    <div class="col-sm-6 col-md-6">
      <div class="dropdown form-group">
        <label for="Districts">Select District</label>
        <select name="Districts" <?php echo (isset($assemblyId) && $assemblyId == 0) ? ' disabled ' : '';?> class="districts form-control">
          <option value="0">Select District</option>
          <?php if(isset($districts) && count($districts) > 0){
            foreach ($districts as $district) {?>
            <option <?php echo (isset($districtId) && $districtId == $district['id']) ? ' selected ' : '';?>value="<?php echo $district['id'];?>"><?php echo $district['name'];?></option>
          <?php }}?>
        </select>
      </div>
    </div>
  </div>
</div>
<div class="container col-md-8">
  <div class="row col-sm-12 col-md-12">
    <div class="col-sm-12 col-md-6">
      <div class="dropdown form-group">
        <label for="blocks">Select Block</label>
        <select name="blocks" <?php echo (isset($districtId) && $districtId == 0) ? ' disabled ' : '';?> class="blocks form-control">
          <option value="0">Select Block</option>
          <?php if(isset($blocks) && count($blocks) > 0){
            foreach ($blocks as $block) {?>
            <option <?php echo (isset($blockId) && $blockId == $block['id']) ? ' selected ' : '';?>value="<?php echo $block['id'];?>"><?php echo $block['name'];?></option>
          <?php }}?>
        </select>
      </div>
    </div>
    <div class="col-sm-6 col-md-6">
      <div class="dropdown form-group">
        <label for="panchayats">Select Panchayat</label>
        <select name="panchayats" <?php echo (isset($blockId) && $blockId == 0) ? ' disabled ' : '';?> class="panchayats form-control">
          <option value="0">Select Panchayat</option>
          <?php if(isset($panchayats) && count($panchayats) > 0){
            foreach ($panchayats as $panchayat) {?>
            <option <?php echo (isset($panchayatId) && $panchayatId == $panchayat['id']) ? ' selected ' : '';?>value="<?php echo $panchayat['id'];?>"><?php echo $panchayat['name'];?></option>
          <?php }}?>
        </select>
      </div>
    </div>
</div>
<div class="row col-sm-12 col-md-12">
    <div class="col-sm-12 col-md-6">
      <div class="dropdown form-group">
        <label for="villages">Select Village</label>
        <select name="villages" <?php echo (isset($panchayatId) && $panchayatId == 0) ? ' disabled ' : '';?> class="villages form-control">
          <option value="0">Select Village</option>
          <?php if(isset($villages) && count($villages) > 0){
            foreach ($villages as $village) {?>
            <option <?php echo (isset($villageId) && $villageId == $village['id']) ? ' selected ' : '';?>value="<?php echo $village['id'];?>"><?php echo $village['name'];?></option>
          <?php }}?>
        </select>
      </div>
    </div>
    <div class="col-sm-6 col-md-6">
      <div class="dropdown form-group">
        <label for="booths">Select Booth</label>
        <select name="booths" <?php echo (isset($villageId) && $villageId == 0) ? ' disabled ' : '';?> class="booths form-control">
          <option value="0">Select Booth</option>
          <?php if(isset($booths) && count($booths) > 0){
           foreach ($booths as $booth) {?>
            <option <?php echo (isset($boothId) && $boothId == $booth['id']) ? ' selected ' : '';?>value="<?php echo $booth['id'];?>"><?php echo $booth['name'];?></option>
          <?php }}?>
        </select>
      </div>
    </div>
</div>
<div class="row col-sm-12 col-md-12">
    <div class="col-sm-12 col-md-6">
      <label for="cars">Enter name</label>
      <input type="text" id="name" class="form-control" <?php echo (isset($boothId) && $boothId == 0) ? ' disabled ' : '';?> placeholder="Name">
    </div>
    <div class="col-sm-12 col-md-6">
    	<label for="cars">Enter Mobile</label>
      	<input type="text" id="mobile" class="form-control" <?php echo (isset($boothId) && $boothId == 0) ? ' disabled ' : '';?> placeholder="Mobile">
    </div>
</div>
<div class="row col-sm-12 col-md-12">
    <div class="col-sm-12 col-md-6">
    	<label for="cars">Enter Email</label>
    	<input type="text" id="email" class="form-control" <?php echo (isset($boothId) && $boothId == 0) ? ' disabled ' : '';?> placeholder="Email">
    </div>
    <div class="col-sm-6 col-md-6">
      <div class="dropdown form-group">
        <label for="booths">Select Gender</label>
        <select id="gender" name="booths" <?php echo (isset($boothId) && $boothId == 0) ? ' disabled ' : '';?> class="booths form-control">
          <option value="1">Female</option>
          <option value="2">Male</option>
          <option value="3">Others</option>
        </select>
      </div>
    </div>
</div>
<div class="row col-sm-12 col-md-12">
    <div class="col-sm-12 col-md-6">
    	<label for="cars">Enter Address</label>
      	<input type="text" id="address" <?php echo (isset($boothId) && $boothId == 0) ? ' disabled ' : '';?> class="form-control" placeholder="Address">
    </div>
    <div class="col-sm-12 col-md-6">
    	<label for="cars">Enter Pincode</label>
      	<input type="text" id="pincode" <?php echo (isset($boothId) && $boothId == 0) ? ' disabled ' : '';?> class="form-control" placeholder="Pincode">
    </div>
  </div>
</div>
<div class="col-auti" style="text-align: center; margin-top: 10px;">
    <button type="button" id='saveBoothPresident' class="btn btn-primary mb-2">Submit</button>
</div>
 
<div class="container" style="margin-top: 50px;">
  <?php //if(isset($voters) && count($voters) > 0){?>
  <table id='voterTable' class='display dataTable' style="display: none;">
    <thead>
      <tr>
        <th>Name</th>
        <th>Mobile</th>
        <th>Email</th>
        <th>Gender</th>
        <th>Pincode</th>
        <th>Address</th>
      </tr>
    </thead>
 </table>
<?php //}?>
</div>
</body>
</html>
<script>
	function validate_name(name) {
        var re = /^[a-z ,.'-]+$/i;
        return re.test(name);
    }

    function validate_email(email) {
    	var re = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    	return re.test(email);
    }
        
    function validate_mobile(mobile) {
        var re = /^(\+\d{1,3}[- ]?)?\d{10}$/;
        return re.test(mobile);
    }
        
    function validate_address(address){
        var re = /^\s*\S+(?:\s+\S+){2}/;
        return re.test(address);
    }

    function validate_pincode(pincode){
        var re = /^\d{6}$/;
        return re.test(pincode);
    }
    
    function validate_ayushman(ayushman){
        var re = /^\d{14}$/;
        return re.test(ayushman);
    }
    
    function validate_aadhaar(aadhaar){
        var re = /^\d{12}$/;
        return re.test(aadhaar);
    }

	$('#saveBoothPresident').on('click', function(event) {
  		event.preventDefault();
  		$("#error").hide();
  		var data = {};
		console.log('saveBoothPresident is called');
		data['parliament'] = $(".parliaments").val();
      	data['assembly'] = $(".assemblies").val();
      	data['block'] = $(".blocks").val();
      	data['booth'] = $(".booths").val();
      	data['user_gender'] = $("#gender").val();
     
      	if (data['parliament'] == 0 || data['assembly'] == 0 || data['block'] == 0 || data['booth'] == 0){
      		$("#error").text("Please select correct values from dropdown!");
      		$("#error").show();
      		return;
      	}
        
        data['name'] = $("#name").val();
        if (data['name'].trim() === "" || !validate_name(data['name'])){
      		$("#error").text("Please Enter  valid name (Characters only)!");
      		$("#error").show();
      		return;
        }

        data['mobile'] = $("#mobile").val();
        if (data['mobile'].trim() === "" || !validate_mobile(data['mobile'])){
      		$("#error").text("Please Enter 10 digint mobile number!");
      		$("#error").show();
      		return;
        }

        data['email'] = $("#email").val();
        if (data['email'].trim() === "" || !validate_email(data['email'])){
      		$("#error").text("Please Enter valid email!");
      		$("#error").show();
      		return;
        }

        data['address'] = $("#address").val();
        if (data['address'].trim() === "" || !validate_address(data['address'])){
      		$("#error").text("Please Enter valid address!");
      		$("#error").show();
      		return;
        }

        data['pincode'] = $("#pincode").val();
        if (data['pincode'].trim() === "" || !validate_pincode(data['pincode'])){
      		$("#error").text("Please Enter 6 digit pincode!");
      		$("#error").show();
      		return;
        }
        console.log(' calling backend');
    	$.ajax({
        	type: "POST",
         	url: "saveBoothPresident", 
         	data: {"data": data},
         	dataType: "text",  
         	cache:false,
         	success: function(data, status){
                if (status === "success" && data == "201"){
              		$("#success").show();
              		setTimeout(function(){
					   window.location.reload(1);
					}, 3000);
            	} else {
            		$("#error").text("Please try after some time!");
            		$("#error").show();
            	}
          	}
        });
    });

  // $('.parliaments').change(function(){
  //   $("#parliament").val($(this).val());
  //   document.getElementById("form").submit();
  // });

  $('.assemblies').change(function(){
      // $("#parliament").val($(this).val());
      $("#assembly").val($(this).val());
      if ($(this).val() == 0){
        $("#district").val(0);
        $("#block").val(0);
        $("#panchayat").val(0);
        $("#village").val(0);
        $("#booth").val(0);
      }
      document.getElementById("form").submit();
   });

   $('.districts').change(function(){
      // $("#parliament").val($(".parliaments").val());
      $("#assembly").val($(".assemblies").val());
      $("#district").val($(this).val());
      document.getElementById("form").submit();
   });

   $('.blocks').change(function(){
      // $("#parliament").val($(".parliaments").val());
      $("#assembly").val($(".assemblies").val());
      $("#district").val($(".districts").val());
      $("#block").val($(this).val());
      document.getElementById("form").submit();
   });

   $('.panchayats').change(function(){
      // $("#parliament").val($(".parliaments").val());
      $("#assembly").val($(".assemblies").val());
      $("#district").val($(".districts").val());
      $("#block").val($(".blocks").val());
      $("#panchayat").val($(this).val());
      document.getElementById("form").submit();
   });

   $('.villages').change(function(){
      // $("#parliament").val($(".parliaments").val());
      $("#assembly").val($(".assemblies").val());
      $("#district").val($(".districts").val());
      $("#block").val($(".blocks").val());
      $("#panchayat").val($(".panchayats").val());
      $("#village").val($(this).val());
      document.getElementById("form").submit();
   });


   $('.booths').change(function(){
      // $("#parliament").val($(".parliaments").val());
      $("#assembly").val($(".assemblies").val());
      $("#district").val($(".districts").val());
      $("#block").val($(".blocks").val());
      $("#panchayat").val($(".panchayats").val());
      $("#village").val($(".villages").val());
      $("#booth").val($(this).val());
      $('#name').prop("disabled", false);
      $('#mobile').prop("disabled", false);
      $('#email').prop("disabled", false);
      $('#gender').prop("disabled", false); 
      $('#address').prop("disabled", false);
      $('#pincode').prop("disabled", false); 
   });
</script>